.libPaths()
library("testthat")
library("ggstance")

test_check("ggstance")
