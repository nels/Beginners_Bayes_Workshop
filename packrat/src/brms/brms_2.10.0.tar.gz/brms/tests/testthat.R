library(testthat)
library(brms)

test_check("brms")
