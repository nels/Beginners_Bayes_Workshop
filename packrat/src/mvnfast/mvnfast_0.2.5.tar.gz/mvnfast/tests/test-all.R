library(testthat)
library(mvnfast)

test_package("mvnfast")
